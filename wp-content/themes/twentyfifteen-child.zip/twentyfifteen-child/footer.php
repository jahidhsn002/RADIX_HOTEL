				<!--GET IN TOUCH-->
					<div class="touch-section">
					<div class="container">
						<h3>get in touch</h3>
						<div class="touch-grids">
							<?php dynamic_sidebar('sidebar-4'); ?>
						</div>
					</div>
					</div>
				<!--GET IN TOUCH-->
			</div>
			<!--footer-->
		<?php wp_footer(); ?>
</body>
</html>
